#include <DxLib.h>
#include <cmath>
#include "../Utility/AsoUtility.h"
#include "../Application.h"
#include "../Manager/ResourceManager.h"
#include "../Manager/SceneManager.h"
#include "../Manager/InputManager.h"
#include "../Manager/Camera.h"
#include "../Object/Player.h"
#include "../Object/Enemy.h"
#include "../Object/Common/AnimationController.h"
#include "../Shader/Common/PostEffect.h"
#include "ResultScene.h"

ResultScene::ResultScene(Player::PLAYER_STATE playerState)
{
	animationController_ = nullptr;
	playerState_ = playerState;
}

ResultScene::~ResultScene(void)
{
}

void ResultScene::Init(void)
{
	// �摜�ǂݍ���
	images_.emplace(ResourceManager::SRC::CLEAR, resMng_.Load(ResourceManager::SRC::CLEAR).handleId_);
	images_.emplace(ResourceManager::SRC::STAR, resMng_.Load(ResourceManager::SRC::STAR).handleId_);
	images_.emplace(ResourceManager::SRC::GAMECLEAR_BG, resMng_.Load(ResourceManager::SRC::GAMECLEAR_BG).handleId_);
	images_.emplace(ResourceManager::SRC::GAMEOVER_CAGE, resMng_.Load(ResourceManager::SRC::GAMEOVER_CAGE).handleId_);
	images_.emplace(ResourceManager::SRC::GAMEOVER, resMng_.Load(ResourceManager::SRC::GAMEOVER).handleId_);
	images_.emplace(ResourceManager::SRC::GAMEOVER_BG, resMng_.Load(ResourceManager::SRC::GAMEOVER_BG).handleId_);

	// �T�E���h�ǂݍ���
	sounds_.emplace(ResourceManager::SRC::GAMECLEAR_BGM, resMng_.Load(ResourceManager::SRC::GAMECLEAR_BGM).handleId_);
	sounds_.emplace(ResourceManager::SRC::GAMEOVER_BGM, resMng_.Load(ResourceManager::SRC::GAMEOVER_BGM).handleId_);
	sounds_.emplace(ResourceManager::SRC::SELECT_SE, resMng_.Load(ResourceManager::SRC::SELECT_SE).handleId_);

	// �v���C���[
	charactor_.SetModel(resMng_.LoadModelDuplicate(ResourceManager::SRC::PLAYER));
	charactor_.pos = { 0.0f, PLAYER_POS_Y, 0.0f };
	charactor_.scl = { PLAYER_SIZE, PLAYER_SIZE, PLAYER_SIZE };
	charactor_.quaRot = Quaternion::Euler(
		PLAYER_ROT_X, 0.0f, 0.0f);
	charactor_.Update();

	// �A�j���[�V�����̐ݒ�
	std::string path = Application::PATH_MODEL + "Player/";
	animationController_ = std::make_unique<AnimationController>(charactor_.modelId);

	// �A�j���[�V�����̒ǉ�
	animationController_->Add((int)Player::ANIM_TYPE::LOSE, path + "RLose.mv1", AnimationController::ANIM_SPEED);
	animationController_->Add((int)Player::ANIM_TYPE::VICTORY, path + "RVictory.mv1", AnimationController::ANIM_SPEED);

	// �A�j���[�V����������
	if (playerState_ == Player::PLAYER_STATE::VICTORY)
	{
		animationController_->Play((int)Player::ANIM_TYPE::VICTORY);
		PlaySoundMem(sounds_.at(ResourceManager::SRC::GAMECLEAR_BGM), DX_PLAYTYPE_LOOP, true);
		ChangeVolumeSoundMem(ResourceManager::VOL_GAMECLEAR_BGM, sounds_.at(ResourceManager::SRC::GAMECLEAR_BGM));
	}
	else
	{
		animationController_->Play((int)Player::ANIM_TYPE::LOSE);
		PlaySoundMem(sounds_.at(ResourceManager::SRC::GAMEOVER_BGM), DX_PLAYTYPE_LOOP, true);
		ChangeVolumeSoundMem(ResourceManager::VOL_GAMEOVER_BGM, sounds_.at(ResourceManager::SRC::GAMEOVER_BGM));
	}

	// ���ʒ���
	ChangeVolumeSoundMem(ResourceManager::VOL_SELECT_SE, sounds_.at(ResourceManager::SRC::SELECT_SE));

	// ��_�J�����ɕύX
	auto camera = SceneManager::GetInstance().GetCamera();
	camera->ChangeMode(Camera::MODE::FIXED_POINT);

	// �r�l�b�g�̒ǉ�
	postEffect_.push_back(std::make_unique<PostEffect>("Vignette.cso"));

	// �|�X�g�G�t�F�N�g������
	for (auto& p : postEffect_)
	{
		p->Init();
	}

	// �G�t�F�N�g������
	for (int i = 0; i < NUM_EFFECT; ++i)
	{
		effects_[i].x = static_cast<float>(rand() % Application::SCREEN_SIZE_X);
		effects_[i].y = static_cast<float>(rand() % Application::SCREEN_SIZE_Y - Application::SCREEN_SIZE_Y);  // ��ʊO����J�n
		effects_[i].size = static_cast<float>(rand() % EFFECT_SIZE_MAX + EFFECT_SIZE_MIN);  // �����_���ȃT�C�Y
		effects_[i].color = GetColor(rand() % 256, rand() % 256, rand() % 256);  // �����_���ȐF
		// ����������p�x��ς���
		if (i < NUM_STAR)
		{
			effects_[i].rotation = static_cast<float>(rand() % 360);  // �����_���Ȋp�x
		}
	}
}

void ResultScene::Update(void)
{
	// �Q�[���N���A���ǂ���
	if (playerState_ == Player::PLAYER_STATE::VICTORY)
	{
		// �Q�[���N���AUpdate���s
		UpdateGameClear();
	}
	else
	{
		// �Q�[���I�[�o�[Update���s
		UpdateGameOver();
	}
	
	charactor_.Update();

	// �A�j���[�V�����Đ�
	animationController_->Update();
}

void ResultScene::UpdateGameClear(void)
{
	InputManager& ins = InputManager::GetInstance();
	auto delta = SceneManager::GetInstance().GetDeltaTime();

	// �G�t�F�N�g�ړ�
	for (int i = 0; i < NUM_EFFECT; ++i) {
		// Y���W���X�V
		effects_[i].y += EFFECT_SPEED;

		// ��ʊO�ɏo����Ĕz�u
		if (effects_[i].y > Application::SCREEN_SIZE_Y) {
			effects_[i].y = -(EFFECT_SIZE_MAX + EFFECT_SIZE_MIN);
			effects_[i].x = static_cast<float>(rand() % Application::SCREEN_SIZE_X);
			effects_[i].color = GetColor(rand() % 256, rand() % 256, rand() % 256);  // �V���������_���ȐF
			effects_[i].rotation = static_cast<float>(rand() % 360);  // �����_���Ȋp�x
		}
	}

	// �^�C�g���V�[���ɑJ��
	if (ins.IsTrgDown(KEY_INPUT_SPACE))
	{
		PlaySoundMem(sounds_.at(ResourceManager::SRC::SELECT_SE), DX_PLAYTYPE_BACK, true);
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::TITLE, true);
	}
}

void ResultScene::UpdateGameOver(void)
{
	InputManager& ins = InputManager::GetInstance();
	auto delta = SceneManager::GetInstance().GetDeltaTime();

	// �Q�[���V�[���ɑJ��
	if (ins.IsTrgDown(KEY_INPUT_SPACE))
	{
		PlaySoundMem(sounds_.at(ResourceManager::SRC::SELECT_SE), DX_PLAYTYPE_BACK, true);
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAME, true);
	}
}

void ResultScene::Draw(void)
{
	// �Q�[���N���A���Q�[���I�[�o�[���ǂ���
	if (playerState_ == Player::PLAYER_STATE::VICTORY)
	{
		DrawGameClear();
	}
	else
	{
		DrawGameOver();
	}
}

void ResultScene::DrawGameClear(void)
{
	// �Q�[���N���A
	DrawGraph(0, 0, images_.at(ResourceManager::SRC::GAMECLEAR_BG), false);
	MV1DrawModel(charactor_.modelId);

	// ������Ɛ��`�̕`��
	for (int i = 0; i < NUM_STAR; ++i) {
		DrawRotaGraph(static_cast<int>(effects_[i].x), static_cast<int>(effects_[i].y),
			1.0, effects_[i].rotation, images_.at(ResourceManager::SRC::STAR), true);
	}
	for (int p = NUM_STAR; p < NUM_EFFECT; ++p)
	{
		DrawBox(static_cast<int>(effects_[p].x), static_cast<int>(effects_[p].y),
			static_cast<int>(effects_[p].x + effects_[p].size),
			static_cast<int>(effects_[p].y + effects_[p].size), effects_[p].color, true);
	}

	DrawRotaGraph(Application::SCREEN_SIZE_X / 2, LESULT_GAME_POS_Y,
		LESULT_GAME_SIZE, 0.0, images_.at(ResourceManager::SRC::CLEAR), true);
}

void ResultScene::DrawGameOver(void)
{
	// �Q�[���I�[�o�[
	DrawGraph(0, 0, images_.at(ResourceManager::SRC::GAMEOVER_BG), false);
	MV1DrawModel(charactor_.modelId);
	DrawRotaGraphFast3(Application::SCREEN_SIZE_X / 2, Application::SCREEN_SIZE_Y / 2,
		Application::SCREEN_SIZE_X / 2, Application::SCREEN_SIZE_Y / 2,
		1.0f, 1.0f, 0.0, images_.at(ResourceManager::SRC::GAMEOVER_CAGE), true, false, false);

	DrawRotaGraph(Application::SCREEN_SIZE_X / 2, LESULT_GAME_POS_Y,
		LESULT_GAME_SIZE, 0.0, images_.at(ResourceManager::SRC::GAMEOVER), true);
	
	// �|�X�g�G�t�F�N�g�\��
	for (auto& p : postEffect_)
	{
		p->Draw();
	}
}
