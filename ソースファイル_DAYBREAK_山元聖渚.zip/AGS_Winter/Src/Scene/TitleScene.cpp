#include <DxLib.h>
#include "../Manager/ResourceManager.h"
#include "../Manager/InputManager.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera.h"
#include "../Application.h"
#include "TitleScene.h"

TitleScene::TitleScene(void)
{
}

TitleScene::~TitleScene(void)
{
}

void TitleScene::Init(void)
{
	// �摜�ǂݍ���
	imageTitle_ = resMng_.Load(ResourceManager::SRC::TITLE).handleIds_;
	images_.emplace(ResourceManager::SRC::TITLE_UI, resMng_.Load(ResourceManager::SRC::TITLE_UI).handleId_);
	images_.emplace(ResourceManager::SRC::FLASHLIGHT, resMng_.Load(ResourceManager::SRC::FLASHLIGHT).handleId_);

	// �T�E���h�ǂݍ���
	sounds_.emplace(ResourceManager::SRC::TITLE_BGM, resMng_.Load(ResourceManager::SRC::TITLE_BGM).handleId_);
	sounds_.emplace(ResourceManager::SRC::SELECT_SE, resMng_.Load(ResourceManager::SRC::SELECT_SE).handleId_);
	sounds_.emplace(ResourceManager::SRC::MOVE_SE, resMng_.Load(ResourceManager::SRC::MOVE_SE).handleId_);

	// ��_�J����
	SceneManager::GetInstance().GetCamera()->ChangeMode(Camera::MODE::FIXED_POINT);

	// ���ʒ���
	ChangeVolumeSoundMem(ResourceManager::VOL_TITLE_BGM, sounds_.at(ResourceManager::SRC::TITLE_BGM));
	ChangeVolumeSoundMem(ResourceManager::VOL_MOVE_SE, sounds_.at(ResourceManager::SRC::MOVE_SE));
	ChangeVolumeSoundMem(ResourceManager::VOL_SELECT_SE, sounds_.at(ResourceManager::SRC::SELECT_SE));

	// �^�C�g��BGM�𗬂�
	PlaySoundMem(sounds_.at(ResourceManager::SRC::TITLE_BGM), DX_PLAYTYPE_LOOP, true);

	countAnim_ = 0;
	count_ = 0;
	isLRFlag_ = false;
}

void TitleScene::Update(void)
{
	InputManager& ins = InputManager::GetInstance();
	auto player = InputManager::GetInstance().GetJPadInputState(InputManager::JOYPAD_NO::PAD1);

	// �V�[���J�ڔ���
	if (!isLRFlag_ && ins.IsTrgDown(KEY_INPUT_SPACE) || !isLRFlag_ && ins.IsPadBtnNew(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::RIGHT))
	{
		PlaySoundMem(sounds_.at(ResourceManager::SRC::SELECT_SE), DX_PLAYTYPE_BACK, true);
		// �V�[���J��
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAME, true);
	}
	if (isLRFlag_ && ins.IsTrgDown(KEY_INPUT_SPACE) || isLRFlag_ && ins.IsPadBtnNew(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::RIGHT))
	{
		PlaySoundMem(sounds_.at(ResourceManager::SRC::SELECT_SE), DX_PLAYTYPE_BACK, true);
		// �I���t���O��true�ɂ���
		SceneManager::GetInstance().SetQuitFlag(true);
	}

	// �A�j���[�V�����J�E���g������܂ł�������0�ɖ߂�
	if (countAnim_ > ANIM_COUNT_MAX)
	{
		countAnim_ = 0;
	}
	countAnim_++;

	// �ړ��摜�̕\������
	if (!isLRFlag_ && ins.IsTrgDown(KEY_INPUT_D) || ins.IsTrgDown(KEY_INPUT_RIGHT) || player.AKeyLX > NUM_PAD)
	{
		isLRFlag_ = true;
		PlaySoundMem(sounds_.at(ResourceManager::SRC::MOVE_SE), DX_PLAYTYPE_BACK, true);
	}
	// �E�����������Ă�����
	if (isLRFlag_ && ins.IsTrgDown(KEY_INPUT_A) || ins.IsTrgDown(KEY_INPUT_LEFT) || player.AKeyLX < -NUM_PAD)
	{
		isLRFlag_ = false;
		PlaySoundMem(sounds_.at(ResourceManager::SRC::MOVE_SE), DX_PLAYTYPE_BACK, true);
	}
}

void TitleScene::Draw(void)
{
	// �w�i�A�j���[�V�����̕\���v�Z
	if (countAnim_ % ANIM_COUNT == 0)
	{
		count_ = abs(countAnim_ % (NUM_IMAGES + 1) - (NUM_IMAGES - 1));
	}
	
	// �w�i�̕`��
	DrawRotaGraph(Application::SCREEN_SIZE_X / 2, Application::SCREEN_SIZE_Y / 2, 1.0f, 0.0, imageTitle_[count_], true);

	// �����d���̕`��
	if (isLRFlag_)
	{
		DrawGraph(Application::SCREEN_SIZE_X / 2, FLASHLIGHT_POS_Y, images_.at(ResourceManager::SRC::FLASHLIGHT), true);
	}
	else
	{
		DrawGraph(FLASHLIGHT_LPOS_X, FLASHLIGHT_POS_Y, images_.at(ResourceManager::SRC::FLASHLIGHT), true);
	}

	//UI�̕`��
	DrawRotaGraph(Application::SCREEN_SIZE_X / 2, Application::SCREEN_SIZE_Y / 2, 1.0f, 0.0, images_.at(ResourceManager::SRC::TITLE_UI), true);
}