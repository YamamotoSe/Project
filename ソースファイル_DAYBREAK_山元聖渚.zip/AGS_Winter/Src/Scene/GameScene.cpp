#include <DxLib.h>
#include "../Manager/SceneManager.h"
#include "../Manager/ResourceManager.h"
#include "../Manager/Camera.h"
#include "../Application.h"
#include "../Object/Stage.h"
#include "../Object/Player.h"
#include "../Object/Enemy.h"
#include "../Object/Timer.h"
#include "GameScene.h"

GameScene::GameScene(void)
{
	stage_ = nullptr;
	player_ = nullptr;
	for (auto& e : enemy_)
	{
		e = nullptr;
	}
	timer_ = nullptr;
}

GameScene::~GameScene(void)
{
}

void GameScene::Init(void)
{
	// �摜�ǂݍ���
	images_.emplace(ResourceManager::SRC::GAME_UI_KEY, resMng_.Load(ResourceManager::SRC::GAME_UI_KEY).handleId_);
	images_.emplace(ResourceManager::SRC::RULE, resMng_.Load(ResourceManager::SRC::RULE).handleId_);

	// �T�E���h�ǂݍ���
	sounds_.emplace(ResourceManager::SRC::GAME_BGM, resMng_.Load(ResourceManager::SRC::GAME_BGM).handleId_);
	sounds_.emplace(ResourceManager::SRC::HIT_SE, resMng_.Load(ResourceManager::SRC::HIT_SE).handleId_);

	// ���ʒ���
	ChangeVolumeSoundMem(ResourceManager::VOL_GAME_BGM, sounds_.at(ResourceManager::SRC::GAME_BGM));
	ChangeVolumeSoundMem(ResourceManager::VOL_HIT_SE, sounds_.at(ResourceManager::SRC::HIT_SE));

	// �Q�[��BGM�𗬂�
	PlaySoundMem(sounds_.at(ResourceManager::SRC::GAME_BGM), DX_PLAYTYPE_LOOP, true);

	// �v���C���[
	player_ = std::make_shared<Player>();
	player_->Init();
	SceneManager::GetInstance().GetCamera()->ChangeMode(Camera::MODE::FOLLOW);
	SceneManager::GetInstance().GetCamera()->SetFollow(&player_->GetTransform());
	SceneManager::GetInstance().GetCamera()->SetBeforeDrawFollow();

	// �G�l�~�[
	for (int i = 0; i <= NUM_ENEMY; i++)
	{
		enemy_.push_back(std::make_shared<Enemy>());
	}

	for (auto& e : enemy_)
	{
		e->Init();
		e->SetPlayerPos(&player_->GetTransform());
	}
	enemy_[NUM_ENEMY]->SetEnemyPos(ENEMY_FIXED_POS);

	// �X�e�[�W
	stage_ = std::make_unique<Stage>(*player_, enemy_);
	stage_->Init();

	// �^�C�}�[
	timer_ = std::make_unique<Timer>();
	timer_->Init();

	isRuleFlag_ = true;
	countRule_ = 0.0f;

	selectedFlag_ = false;
}

void GameScene::Update(void)
{
	if (countRule_ >= RULE_COUNT)
	{
		isRuleFlag_ = false;
	}

	if (isRuleFlag_)
	{
		countRule_ += SceneManager::GetInstance().GetDeltaTime();
		return;
	}

	for (auto& e : enemy_)
	{
		e->Update();
	}
	player_->Update();
	stage_->Update();
	timer_->Update();

	for (auto& e : enemy_)
	{
		// �v���C���[�ƃG�l�~�[�̓����蔻��
		VECTOR pPos = player_->GetPos();
		VECTOR ePos = e->GetPos();
		VECTOR diff = VSub(pPos, ePos);
		float distance = diff.x * diff.x + diff.z * diff.z;

		if (distance < HIT_DISTANCE)
		{
			PlaySoundMem(sounds_.at(ResourceManager::SRC::HIT_SE), DX_PLAYTYPE_BACK, true);
			player_->ChangeState(Player::PLAYER_STATE::LOSE);
			SceneManager::GetInstance().SetState(player_->GetState());
			SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::RESULT, true);
		}
	}

	// �������Ԃ��O�ɂȂ�����N���A
	// ���U���g�V�[���ɑJ��
	auto time = timer_->GetTimeCount();
	if (time < Timer::TIME_LIMIT_FINISH)
	{
		player_->ChangeState(Player::PLAYER_STATE::VICTORY);
		SceneManager::GetInstance().SetState(player_->GetState());
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::RESULT, true);
	}
}

void GameScene::Draw(void)
{
	stage_->Draw();
	
	for (auto& e : enemy_)
	{
		e->Draw();
	}

	player_->Draw();

	timer_->Draw();

	// UI�\��
	DrawGraph(Application::SCREEN_SIZE_X - UI_SIZE_X, Application::SCREEN_SIZE_Y - UI_SIZE_Y, images_.at(ResourceManager::SRC::GAME_UI_KEY), true);

	// ���[���\��
	if (isRuleFlag_)
	{
		DrawGraph(RULE_POS_X, Application::SCREEN_SIZE_Y / 2 - UI_SIZE_Y * 2, images_.at(ResourceManager::SRC::RULE), true);
	}
}