#include <DxLib.h>
#include "../Application.h"
#include "Resource.h"
#include "ResourceManager.h"

ResourceManager* ResourceManager::instance_ = nullptr;

void ResourceManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new ResourceManager();
	}
	instance_->Init();
}

ResourceManager& ResourceManager::GetInstance(void)
{
	return *instance_;
}

void ResourceManager::Init(void)
{
	static std::string PATH_IMG = Application::PATH_IMAGE;
	static std::string PATH_MDL = Application::PATH_MODEL;
	static std::string PATH_SOU = Application::PATH_SOUND;

	Resource* res;

	// �^�C�g���摜
	res = new Resource(Resource::TYPE::IMGS, PATH_IMG + "titleBg.png", 1, 3, Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y);
	resourcesMap_.emplace(SRC::TITLE, res);

	// �^�C�g����UI
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "titleUI.png");
	resourcesMap_.emplace(SRC::TITLE_UI, res);

	// �^�C�g����BGM
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "titleBGM.mp3");
	resourcesMap_.emplace(SRC::TITLE_BGM, res);

	// �����d��
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "flashlight.png");
	resourcesMap_.emplace(SRC::FLASHLIGHT, res);

	// �Z���N�g��ʂ̔w�i
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "selectBG.png");
	resourcesMap_.emplace(SRC::SELECT_BG, res);

	// ���艹
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "selectSE.mp3");
	resourcesMap_.emplace(SRC::SELECT_SE, res);

	// �I���ړ���
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "moveSE.mp3");
	resourcesMap_.emplace(SRC::MOVE_SE, res);

	// �Q�[����UI(XBOX)
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "gameUI.png");
	resourcesMap_.emplace(SRC::GAME_UI_XBOX, res);

	// �Q�[����UI(KEY)
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "gameUI2.png");
	resourcesMap_.emplace(SRC::GAME_UI_KEY, res);

	// �Q�[��BGM
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "gameBGM.mp3");
	resourcesMap_.emplace(SRC::GAME_BGM, res);

	// ���[��
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "rule.png");
	resourcesMap_.emplace(SRC::RULE, res);
	
	// �v���C���[
	res = new Resource(Resource::TYPE::MODEL, PATH_MDL + "Player/Player.mv1");
	resourcesMap_.emplace(SRC::PLAYER, res);

	// ����
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "walkSE.mp3");
	resourcesMap_.emplace(SRC::WALK_SE, res);

	// �Փˉ�
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "hitSE.mp3");
	resourcesMap_.emplace(SRC::HIT_SE, res);

	// �l�e
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "Shadow.png");
	resourcesMap_.emplace(SRC::SHADOW, res);

	// �G�l�~�[
	res = new Resource(Resource::TYPE::MODEL, PATH_MDL + "Enemy/Enemy.mv1");
	resourcesMap_.emplace(SRC::ENEMY, res);

	// �X�e�[�W
	res = new Resource(Resource::TYPE::MODEL, PATH_MDL + "Stage/Stage2.mv1");
	resourcesMap_.emplace(SRC::STAGE, res);

	// �^�C�}�[
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "time.png");
	resourcesMap_.emplace(SRC::TIME, res);

	// �^�C�}�[�̃t���[��
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "timeFrame.png");
	resourcesMap_.emplace(SRC::TIME_FRANE, res);

	// ����
	res = new Resource(Resource::TYPE::IMGS, PATH_IMG + "number.png", 10, 1, 40, 40);
 	resourcesMap_.emplace(SRC::NUMBER, res);

	// �^�C�g���֖߂�
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "return.png");
	resourcesMap_.emplace(SRC::RETURN_UI, res);

	// ���g���C
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "retry.png");
	resourcesMap_.emplace(SRC::RETRY_UI, res);

	// ���^
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "star.png");
	resourcesMap_.emplace(SRC::STAR, res);

	// GAMEClear
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "clear.png");
	resourcesMap_.emplace(SRC::CLEAR, res);

	// GameOver
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "gameOver.png");
	resourcesMap_.emplace(SRC::GAMEOVER, res);
	
	// �B
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "cage.png");
	resourcesMap_.emplace(SRC::GAMEOVER_CAGE, res);

	// �Q�[���N���A�w�i
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "gameClearBG.jpg");
	resourcesMap_.emplace(SRC::GAMECLEAR_BG, res);

	// �Q�[���N���ABGM
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "gameClearBGM.mp3");
	resourcesMap_.emplace(SRC::GAMECLEAR_BGM, res);

	// �Q�[���I�[�o�[�w�i
	res = new Resource(Resource::TYPE::IMG, PATH_IMG + "gameOverBG.jpg");
	resourcesMap_.emplace(SRC::GAMEOVER_BG, res);

	// �Q�[���I�[�o�[BGM
	res = new Resource(Resource::TYPE::SOUND, PATH_SOU + "gameOverBGM.mp3");
	resourcesMap_.emplace(SRC::GAMEOVER_BGM, res);
}

void ResourceManager::Release(void)
{
	for (auto& p : loadedMap_)
	{
		p.second.Release();
	}

	loadedMap_.clear();
}

void ResourceManager::Destroy(void)
{
	Release();
	resourcesMap_.clear();
	delete instance_;
}

const Resource& ResourceManager::Load(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return dummy_;
	}
	return res;
}

int ResourceManager::LoadModelDuplicate(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return -1;
	}

	int duId = MV1DuplicateModel(res.handleId_);
	res.duplicateModelIds_.push_back(duId);

	return duId;
}

ResourceManager::ResourceManager(void)
{
}

Resource& ResourceManager::_Load(SRC src)
{
	// ���[�h�ς݃`�F�b�N
	const auto& lPair = loadedMap_.find(src);
	if (lPair != loadedMap_.end())
	{
		return *resourcesMap_.find(src)->second;
	}

	// ���\�[�X�o�^�`�F�b�N
	const auto& rPair = resourcesMap_.find(src);
	if (rPair == resourcesMap_.end())
	{
		// �o�^����Ă��Ȃ�
		return dummy_;
	}

	// ���[�h����
	rPair->second->Load();

	// �O�̂��߃R�s�[�R���X�g���N�^
	loadedMap_.emplace(src, *rPair->second);

	return *rPair->second;
}