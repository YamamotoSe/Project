#pragma once

class Vector2
{
public:

	int x;
	int y;

	Vector2(void);

	Vector2(int vX, int vY);

	~Vector2(void);
};