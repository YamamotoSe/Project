#include "Vector2.h"

Vector2::Vector2(void)
{
	x = 0;
	y = 0;
}

Vector2::Vector2(int vX, int vY)
{
	x = vX;
	y = vY;
}

Vector2::~Vector2(void)
{
}