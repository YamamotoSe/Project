#include <DxLib.h>
#include "../../../Manager/SceneManager.h"
#include "../../../Application.h"
#include "PixelMaterial.h"
#include "PixelRenderer.h"

PixelRenderer::PixelRenderer(PixelMaterial& pixelMaterial) 
	: pixelMaterial_(pixelMaterial)
{
}

void PixelRenderer::MakeSquereVertex(Vector2 pos, Vector2 size)
{
	pos_ = pos;
	size_ = size;

	// �S���_�̏�����
	for (int i = 0; i < 4; i++)
	{
		vertexs_[i].rhw = 1.0f;
		vertexs_[i].dif = GetColorU8(255, 255, 255, 255);
		vertexs_[i].spc = GetColorU8(255, 255, 255, 255);
		vertexs_[i].su = 0.0f;
		vertexs_[i].sv = 0.0f;
	}
	// ����
	vertexs_[0].pos = VGet(static_cast<float>(pos_.x), static_cast<float>(pos_.y), 0.0f);
	vertexs_[0].u = 0.0f;
	vertexs_[0].v = 0.0f;
	// �E��
	vertexs_[1].pos = VGet(static_cast<float>(pos_.x + size_.x), static_cast<float>(pos_.y), 0.0f);
	vertexs_[1].u = 1.0f;
	vertexs_[1].v = 0.0f;
	// �E��
	vertexs_[2].pos = VGet(static_cast<float>(pos_.x + size_.x), static_cast<float>(pos_.y + size_.y), 0.0f);
	vertexs_[2].u = 1.0f;
	vertexs_[2].v = 1.0f;
	// ����
	vertexs_[3].pos = VGet(static_cast<float>(pos_.x), static_cast<float>(pos_.y + size_.y), 0.0f);
	vertexs_[3].u = 0.0f;
	vertexs_[3].v = 1.0f;

	// �O�p�`�̒��_�@�v�U�����
	indexes_[0] = 0;
	indexes_[1] = 1;
	indexes_[2] = 3;
	indexes_[3] = 1;
	indexes_[4] = 2;
	indexes_[5] = 3;
}

void PixelRenderer::MakeSquereVertex(void)
{
	float sX = static_cast<float>(0.0f);
	float sY = static_cast<float>(0.0f);
	float eX = static_cast<float>(Application::SCREEN_SIZE_X);
	float eY = static_cast<float>(Application::SCREEN_SIZE_Y);

	// �S���_�̏�����
	for (int i = 0; i < 4; i++)
	{
		vertexs_[i].rhw = 1.0f;
		vertexs_[i].dif = GetColorU8(255, 255, 255, 255);
		vertexs_[i].spc = GetColorU8(255, 255, 255, 255);
		vertexs_[i].su = 0.0f;
		vertexs_[i].sv = 0.0f;
	}
	// ����
	vertexs_[0].pos = VGet(sX, sY, 0.0f);
	vertexs_[0].u = 0.0f;
	vertexs_[0].v = 0.0f;
	// �E��
	vertexs_[1].pos = VGet(eX, sY, 0.0f);
	vertexs_[1].u = 1.0f;
	vertexs_[1].v = 0.0f;
	// �E��
	vertexs_[2].pos = VGet(eX, eY, 0.0f);
	vertexs_[2].u = 1.0f;
	vertexs_[2].v = 1.0f;
	// ����
	vertexs_[3].pos = VGet(sX, eY, 0.0f);
	vertexs_[3].u = 0.0f;
	vertexs_[3].v = 1.0f;

	// �O�p�`�̒��_�@�v�U�����
	indexes_[0] = 0;
	indexes_[1] = 1;
	indexes_[2] = 3;
	indexes_[3] = 1;
	indexes_[4] = 2;
	indexes_[5] = 3;
}

void PixelRenderer::Draw(void)
{
	int mainScreen = SceneManager::GetInstance().GetMainScreen();

	// �|�X�g�G�t�F�N�g
	//-----------------------------------------

	// �V�F�[�_�[�ݒ�
	SetUsePixelShader(pixelMaterial_.shader_);

	// �e�N�X�`���̐ݒ�
	SetUseTextureToShader(0, mainScreen);
	// �萔�o�b�t�@
	FLOAT4* constBufsPtr =
		(FLOAT4*)GetBufferShaderConstantBuffer(pixelMaterial_.constBuf_);
	// ��Z�F
	constBufsPtr->x = 1.0f;
	constBufsPtr->y = 1.0f;
	constBufsPtr->z = 1.0f;
	constBufsPtr->w = 1.0f;

	// �萔�o�b�t�@���X�V���ď������񂾓��e�𔽉f����
	//UpdateShaderConstantBuffer(pixelMaterial_.constBuf_);

	// �萔�o�b�t�@���s�N�Z���V�F�[�_�[�p�萔�o�b�t�@���W�X�^�ɃZ�b�g
	SetShaderConstantBuffer(
		pixelMaterial_.constBuf_, DX_SHADERTYPE_PIXEL, CONSTANT_BUF_SLOT_BEGIN_PS);

	// �`��
	DrawPolygonIndexed2DToShader(vertexs_, NUM_VERTEX, indexes_, NUM_POLYGON);
	//-----------------------------------------
}

void PixelRenderer::Draw(int x, int y)
{
}
