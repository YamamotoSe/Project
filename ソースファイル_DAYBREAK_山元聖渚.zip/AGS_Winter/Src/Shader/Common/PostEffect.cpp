#include <DxLib.h>
#include <memory>
#include "../../Manager/SceneManager.h"
#include "../../Application.h"
#include "Pixel/PixelRenderer.h"
#include "Pixel/PixelMaterial.h"
#include "PostEffect.h"

PostEffect::PostEffect(std::string shaderFileName)
{
	shaderFileName_ = shaderFileName;
}

PostEffect::~PostEffect(void)
{
	DeleteGraph(postEffectScreen_);
}

void PostEffect::Init(void)
{
	// �|�X�g�G�t�F�N�g�p�X�N���[��
	postEffectScreen_ = MakeScreen(
		Application::SCREEN_SIZE_X, Application::SCREEN_SIZE_Y, true);

	pixelMaterials_ = std::make_unique<PixelMaterial>(shaderFileName_, 1);
	
	pixelRenderer_ = std::make_unique<PixelRenderer>(*pixelMaterials_);
	
	pixelRenderer_->MakeSquereVertex();

}

void PostEffect::Draw(void)
{
	int mainScreen = SceneManager::GetInstance().GetMainScreen();

	SetDrawScreen(postEffectScreen_);

	// ��ʂ�������
	ClearDrawScreen();

	pixelRenderer_->Draw();

	// ���C���ɖ߂�
	SetDrawScreen(mainScreen);
	DrawGraph(0, 0, postEffectScreen_, false);
}